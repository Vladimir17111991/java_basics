package ru.skillbox;

public enum Operation {
    ADD,
    SUBTRACT,
    MULTIPLY
}
