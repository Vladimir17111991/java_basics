package ru.skillbox;

public enum BacklightKeyboard {
    YES,
    NO
}
