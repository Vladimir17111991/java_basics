package ru.skillbox;

public enum TypeHardDisk {
    HDD,
    SSD
}
