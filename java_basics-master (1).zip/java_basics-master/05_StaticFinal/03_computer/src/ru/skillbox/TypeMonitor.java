package ru.skillbox;

public enum TypeMonitor {
    IPS,
    TN,
    VA
}
