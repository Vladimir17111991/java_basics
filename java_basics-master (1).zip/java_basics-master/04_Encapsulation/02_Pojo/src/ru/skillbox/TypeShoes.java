package ru.skillbox;

public enum TypeShoes {
    MENS_SHOES,
    WOMENS_SHOES
}
