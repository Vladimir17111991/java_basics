import org.hibernate.Transaction;
import org.hibernate.mapping.PrimaryKey;

import java.util.List;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        while (true) {
            Scanner scanner = new Scanner(System.in);
            Hibernate hibernateStudentSubscriptions = new Hibernate();
            Hibernate hibernateCourseStudents = new Hibernate();
            System.out.println("Введите id студента");
            String idStudent = scanner.nextLine();
           if (idStudent.equals("0")) {
                break;
            }
            Transaction transactionStudSub = hibernateStudentSubscriptions.getSession().beginTransaction();
            //студент->подписки
            Student student = hibernateStudentSubscriptions.getSession().get(Student.class, Integer.parseInt(idStudent));
            List<Subscription> subscriptions = student.getSubscriptionList();
            System.out.println(student.getName());
            subscriptions.forEach(subscription ->
            {
                System.out.println(subscription.getCourseName().getName());
            });
            hibernateStudentSubscriptions.getSessionFactory().close();
            transactionStudSub.commit();
           // курс->преподаватель->студенты
            Transaction transactionCourseStud = hibernateCourseStudents.getSession().beginTransaction();

            System.out.println("Введите id курса");
            String idCourse = scanner.nextLine();
            if (idCourse.equals("0")) {
                break;
            }
            Course course = hibernateCourseStudents.getSession().get(Course.class, Integer.parseInt(idCourse));
            List<Student> listStudents = course.getStudents();

            System.out.println(course.getName()
                    + ". Преподаватель курса -  " + course.getTeacher().getName()
                    + ". Студенты данного курса - ");
            listStudents.forEach(studentCourse -> {
                System.out.println(studentCourse.getName());
            });
            transactionCourseStud.commit();
            hibernateCourseStudents.getSessionFactory().close();

        }
    }
}
