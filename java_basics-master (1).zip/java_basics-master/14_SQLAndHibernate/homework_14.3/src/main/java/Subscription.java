import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "Subscriptions")
public class Subscription {
    @EmbeddedId
    private Key id;

    @Column(name = "subscription_date")
    private Date subscriptionDate;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "student_id",insertable = false,updatable = false)
    private Student student;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "course_id",insertable = false,updatable = false)
    private Course courseName;

    public Course getCourseName() {return courseName;}
    public void setCourseName(Course courseName) {this.courseName = courseName;}

    public Student getStudent() {return student;}
    public void setStudent(Student student) {this.student = student;}

    public Key getId() {return id;}
    public void setId(Key id) {this.id = id;}

    public Date getSubscriptionDate() {return subscriptionDate;}
    public void setSubscriptionDate(Date subscriptionDate) {this.subscriptionDate = subscriptionDate;}

    @Embeddable
    public static class Key implements Serializable {
        public Key(){}

        public Key(int studentId,int courseId) {
            this.studentId = studentId;
             this.courseId = courseId;
        }

        @Column(name = "student_id")
        private int studentId;

        @Column(name = "course_id")
        private int courseId;

        public int getStudentId() {return studentId;}
        public void setStudentId(int studentId) {this.studentId = studentId;}

        public int getCourseId() {return courseId;}
        public void setCourseId(int courseId) {this.courseId = courseId;}

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Key key = (Key) o;
            return studentId == key.studentId && courseId == key.courseId;
        }

        @Override
        public int hashCode() {
            return Objects.hash(studentId, courseId);
        }
    }
}
