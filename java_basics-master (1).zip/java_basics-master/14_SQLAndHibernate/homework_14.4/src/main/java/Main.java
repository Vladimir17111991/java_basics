import org.hibernate.Transaction;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {


            Hibernate hibernateLinkedPurchaseList = new Hibernate();
            Transaction transaction = hibernateLinkedPurchaseList.getSession().beginTransaction();
            CriteriaBuilder builder = hibernateLinkedPurchaseList.getSession().getCriteriaBuilder();
            CriteriaQuery<Purchase> query = builder.createQuery(Purchase.class);
            Root<Purchase> root = query.from(Purchase.class);
            query.select(root);
            List<Purchase> list = hibernateLinkedPurchaseList.session.createQuery(query).getResultList();

            // List<LinkedPurchaseList> listForLinked = hibernateLinkedPurchaseList.getSession().createQuery(query2).getResultList();
            //List<LinkedPurchaseList> listForLinked = new ArrayList<>();
            for (Purchase l : list) {
                LinkedPurchaseList linkedPurchaseList = new LinkedPurchaseList(
                        new LinkedPurchaseList.LinkedKey(l.getStudentName(), l.getCourseName())
                        , l.getPrice()
                        , l.getSubscriptionDate());
                // listForLinked.add(linkedPurchaseList);
                hibernateLinkedPurchaseList.session.saveOrUpdate(linkedPurchaseList);
            }
            transaction.commit();
            hibernateLinkedPurchaseList.getSession().close();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        }
}
