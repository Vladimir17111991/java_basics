import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "LinkedPurchaseList")
public class LinkedPurchaseList {
    @EmbeddedId
    private LinkedKey linkedKey;
//    @OneToOne(optional = false)
//    @JoinColumn(name = "student_name",referencedColumnName = "student_name",insertable = false, updatable = false,foreignKey = @ForeignKey(name = "none"))
//    private Purchase studentName;
//
//    @OneToOne(optional = false)
//    @JoinColumn(name = "course_name", referencedColumnName = "course_name",insertable = false, updatable = false,foreignKey = @ForeignKey(name = "none"))
//    private Purchase courseName;

    @Column(name = "price")
    private int price;
    @Column(name = "subscription_date")
    private Date subscriptionDate;

    public LinkedPurchaseList(LinkedKey linkedKey, int price, Date subscriptionDate) {
        this.linkedKey = linkedKey;
        this.price = price;
        this.subscriptionDate = subscriptionDate;

    }


    public LinkedKey getLinkedKey() {
        return linkedKey;
    }

    public void setLinkedKey(LinkedKey linkedKey) {
        this.linkedKey = linkedKey;
    }

//    public Purchase getStudentName() {
//        return studentName;
//    }
//
//    public void setStudentName(Purchase studentName) {
//        this.studentName = studentName;
//    }
//
//    public Purchase getCourseName() {
//        return courseName;
//    }
//
//    public void setCourseName(Purchase courseName) {
//        this.courseName = courseName;
//    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Date getSubscriptionDate() {
        return subscriptionDate;
    }

    public void setSubscriptionDate(Date subscriptionDate) {
        this.subscriptionDate = subscriptionDate;
    }

    @Embeddable
    public static class LinkedKey implements Serializable {
        public LinkedKey(Student student_id,Course course_id){
            this.student_id = student_id;
            this.course_id = course_id;
        }
        @OneToOne(cascade = CascadeType.ALL)
        @JoinColumn(name = "student_id",referencedColumnName = "id",nullable = false)
        private Student student_id;
        @OneToOne(cascade = CascadeType.ALL)
        @JoinColumn(name = "course_id",referencedColumnName = "id",nullable = false)
        private Course course_id;

        public Student getStudent_id() {
            return student_id;
        }

        public void setStudent_id(Student student_id) {
            this.student_id = student_id;
        }

        public Course getCourse_id() {
            return course_id;
        }

        public void setCourse_id(Course course_id) {
            this.course_id = course_id;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            LinkedKey linkedKey = (LinkedKey) o;
            return student_id == linkedKey.student_id && course_id == linkedKey.course_id;
        }

        @Override
        public int hashCode() {
            return Objects.hash(student_id, course_id);
        }
    }

}