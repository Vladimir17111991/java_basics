public interface Node {
    String getAbsPath();
}
